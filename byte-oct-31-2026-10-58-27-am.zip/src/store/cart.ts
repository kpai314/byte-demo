import { create } from 'zustand';
import type { Food } from '../services/api';

export type CartLine = {
  food: Food;
  quantity: number;
};

export type CartState = {
  outletId: number | null;
  outletName: string | null;
  lines: CartLine[];
  add: (outletId: number, food: Food, forceSwitch?: boolean) => boolean;
  switchOutletAndAdd: (outletId: number, food: Food) => void;
  setQty: (id: number, quantity: number) => void;
  clear: () => void;
  total: () => number;
};

export const useCart = create<CartState>((set, get) => ({
  outletId: null,
  outletName: null,
  lines: [],

  add: (outletId: number, food: Food, forceSwitch = false) => {
    const s = get();
    // Enforce single-outlet rule
    if (s.outletId !== null && s.outletId !== outletId && s.lines.length > 0) {
      if (!forceSwitch) {
        return false; // Signals conflict to caller to ask user
      }
      // Force switch: replace cart with new outlet item
      set({
        outletId,
        outletName: food.outlet_name || `Outlet #${outletId}`,
        lines: [{ food, quantity: 1 }],
      });
      return true;
    }

    const found = s.lines.find(x => x.food.id === food.id);
    set({
      outletId,
      outletName: food.outlet_name || s.outletName || `Outlet #${outletId}`,
      lines: found
        ? s.lines.map(x => x.food.id === food.id ? { ...x, quantity: x.quantity + 1 } : x)
        : [...s.lines, { food, quantity: 1 }],
    });
    return true;
  },

  switchOutletAndAdd: (outletId: number, food: Food) => {
    set({
      outletId,
      outletName: food.outlet_name || `Outlet #${outletId}`,
      lines: [{ food, quantity: 1 }],
    });
  },

  setQty: (id: number, q: number) =>
    set(s => {
      const lines = q <= 0
        ? s.lines.filter(x => x.food.id !== id)
        : s.lines.map(x => x.food.id === id ? { ...x, quantity: q } : x);
      return {
        lines,
        outletId: lines.length ? s.outletId : null,
        outletName: lines.length ? s.outletName : null,
      };
    }),

  clear: () => set({ outletId: null, outletName: null, lines: [] }),

  total: () => get().lines.reduce((acc, x) => acc + x.food.price * x.quantity, 0),
}));
