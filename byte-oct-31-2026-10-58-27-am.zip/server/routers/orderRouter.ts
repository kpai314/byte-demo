import { Router } from 'express';
import { db, runTransaction } from '../db/database';
import { requireAuth, requireVendorOrAdmin } from '../middleware/auth';
import { sendSuccess, sendError } from '../middleware/responseContract';

export const orderRouter = Router();

// Order Checkout & Transactional Creation
orderRouter.post(['/checkout', '/'], requireAuth, (req, res) => {
  const user = req.user!;
  const {
    outlet_id,
    items,
    idempotency_key,
    pickup_type,
    scheduled_time,
    payment_method,
  } = req.body;

  if (!outlet_id) {
    sendError(res, 400, 'BAD_REQUEST', 'outlet_id is required.');
    return;
  }

  if (!Array.isArray(items) || items.length === 0) {
    sendError(res, 400, 'BAD_REQUEST', 'Your campus tray is empty.');
    return;
  }

  // 1. Idempotency Check
  if (idempotency_key) {
    const existing = db.prepare('SELECT * FROM orders WHERE idempotency_key = ?').get(idempotency_key) as any;
    if (existing) {
      if (existing.user_id !== user.id) {
        sendError(res, 409, 'IDEMPOTENCY_CONFLICT', 'Idempotency key has already been used by another transaction.');
        return;
      }
      const existingItems = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(existing.id) as any[];
      const outlet = db.prepare('SELECT outlet_name FROM outlets WHERE id = ?').get(existing.outlet_id) as any;

      sendSuccess(res, {
        id: existing.id,
        order_number: existing.order_number,
        outlet_name: outlet?.outlet_name || 'Campus Canteen',
        pickup_counter: existing.pickup_counter,
        status: existing.order_status,
        payment_status: existing.payment_status,
        subtotal: existing.subtotal,
        total: existing.total_amount,
        pickup_token: existing.pickup_token,
        items: existingItems.map(i => ({
          food_item_id: i.menu_item_id,
          name: i.item_name_snapshot,
          quantity: i.quantity,
          unit_price: i.unit_price_snapshot,
          line_total: i.item_total,
        })),
        message: 'Existing order returned via idempotency key.',
      });
      return;
    }
  }

  // 2. Fetch Outlet
  const outlet = db.prepare('SELECT * FROM outlets WHERE id = ?').get(outlet_id) as any;
  if (!outlet) {
    sendError(res, 404, 'NOT_FOUND', 'Campus outlet not found.');
    return;
  }

  if (outlet.outlet_status !== 'ACTIVE') {
    sendError(res, 403, 'OUTLET_CLOSED', `This outlet is currently ${outlet.outlet_status.toLowerCase()}.`);
    return;
  }

  // 3. Transactional Validation, Stock Decrement, Order & Payment Creation
  try {
    const createdOrder = runTransaction(() => {
      let subtotal = 0;
      const orderLines: Array<{
        menu_item_id: number;
        name: string;
        unit_price: number;
        quantity: number;
        item_total: number;
      }> = [];

      for (const line of items) {
        const itemId = Number(line.food_item_id || line.id);
        const qty = Math.max(1, Number(line.quantity) || 1);

        const menuItem = db.prepare(`
          SELECT id, outlet_id, item_name, price, availability_status, stock_quantity
          FROM menu_items
          WHERE id = ?
        `).get(itemId) as any;

        if (!menuItem) {
          throw new Error(`Item ID ${itemId} does not exist.`);
        }

        if (menuItem.outlet_id !== outlet_id) {
          throw new Error(`Item "${menuItem.item_name}" does not belong to ${outlet.outlet_name}.`);
        }

        if (menuItem.availability_status !== 'AVAILABLE') {
          throw new Error(`Item "${menuItem.item_name}" is currently sold out.`);
        }

        if (menuItem.stock_quantity < qty) {
          throw new Error(`Only ${menuItem.stock_quantity} available for "${menuItem.item_name}".`);
        }

        const lineTotal = menuItem.price * qty;
        subtotal += lineTotal;

        // Atomically decrement stock
        db.prepare(`
          UPDATE menu_items
          SET stock_quantity = stock_quantity - ?,
              availability_status = CASE WHEN stock_quantity - ? <= 0 THEN 'SOLD_OUT' ELSE 'AVAILABLE' END,
              updated_at = datetime('now')
          WHERE id = ?
        `).run(qty, qty, itemId);

        orderLines.push({
          menu_item_id: menuItem.id,
          name: menuItem.item_name,
          unit_price: menuItem.price,
          quantity: qty,
          item_total: lineTotal,
        });
      }

      const total = subtotal; // Taxes/discounts can be applied here
      const orderNum = 'B' + Math.floor(1000 + Math.random() * 9000).toString();
      const pickupToken = 'TK-' + Math.floor(1000 + Math.random() * 9000).toString() + '-EXP';
      const pickupCounter = outlet_id === 3 ? 'EXPRESS WINDOW' : `COUNTER 0${outlet_id}`;
      const resolvedPaymentMethod = payment_method === 'cash' ? 'cash' : 'upi';
      const paymentStatus = resolvedPaymentMethod === 'cash' ? 'CASH_AT_COUNTER' : 'PAID';

      // Insert Order
      const orderResult = db.prepare(`
        INSERT INTO orders (
          order_number, idempotency_key, user_id, outlet_id, subtotal, taxes,
          discounts, total_amount, payment_status, order_status, pickup_token,
          pickup_counter, pickup_type, scheduled_time
        ) VALUES (?, ?, ?, ?, ?, 0, 0, ?, ?, 'PLACED', ?, ?, ?, ?)
      `).run(
        orderNum,
        idempotency_key || `idemp-${Date.now()}-${Math.random()}`,
        user.id,
        outlet_id,
        subtotal,
        total,
        paymentStatus,
        pickupToken,
        pickupCounter,
        pickup_type || 'immediate',
        scheduled_time || null
      );

      const orderId = orderResult.lastInsertRowid;

      // Insert Order Items (Historical Snapshot)
      const itemStmt = db.prepare(`
        INSERT INTO order_items (
          order_id, menu_item_id, item_name_snapshot, unit_price_snapshot,
          quantity, item_total
        ) VALUES (?, ?, ?, ?, ?, ?)
      `);

      for (const line of orderLines) {
        itemStmt.run(
          orderId,
          line.menu_item_id,
          line.name,
          line.unit_price,
          line.quantity,
          line.item_total
        );
      }

      // Insert Sandbox Payment Record
      db.prepare(`
        INSERT INTO payments (
          order_id, payment_provider, payment_reference, amount,
          payment_method, payment_status
        ) VALUES (?, 'SANDBOX_UPI', ?, ?, ?, ?)
      `).run(
        orderId,
        `UPI-REF-${Date.now()}`,
        total,
        resolvedPaymentMethod,
        paymentStatus === 'PAID' ? 'SUCCESS' : 'PENDING'
      );

      return {
        id: Number(orderId),
        order_number: orderNum,
        outlet_name: outlet.outlet_name,
        pickup_counter: pickupCounter,
        status: 'PLACED',
        payment_status: paymentStatus,
        subtotal,
        total,
        pickup_token: pickupToken,
        items: orderLines,
      };
    });

    sendSuccess(res, createdOrder, 'Order placed successfully. Present pickup token at counter.', 201);
  } catch (err: any) {
    sendError(res, 400, 'ORDER_CREATION_FAILED', err.message || 'Transaction could not be completed.');
  }
});

// Student's Own Orders
orderRouter.get('/mine', requireAuth, (req, res) => {
  const user = req.user!;
  const orders = db.prepare(`
    SELECT
      o.*,
      out.outlet_name
    FROM orders o
    JOIN outlets out ON o.outlet_id = out.id
    WHERE o.user_id = ?
    ORDER BY o.created_at DESC
  `).all(user.id) as any[];

  const result = orders.map(o => {
    const items = db.prepare(`
      SELECT item_name_snapshot as name, unit_price_snapshot as unit_price, quantity, item_total as line_total
      FROM order_items
      WHERE order_id = ?
    `).all(o.id);

    return {
      id: o.id,
      order_number: o.order_number,
      outlet_id: o.outlet_id,
      outlet_name: o.outlet_name,
      pickup_counter: o.pickup_counter,
      status: o.order_status,
      order_status: o.order_status,
      payment_status: o.payment_status,
      total: o.total_amount,
      total_amount: o.total_amount,
      pickup_token: o.pickup_token,
      created_at: o.created_at,
      items,
    };
  });

  sendSuccess(res, result);
});

// Vendor / Admin: Active Kitchen Queue Orders
orderRouter.get('/', requireVendorOrAdmin, (req, res) => {
  const user = req.user!;
  let query = `
    SELECT o.*, out.outlet_name
    FROM orders o
    JOIN outlets out ON o.outlet_id = out.id
  `;
  const params: any[] = [];

  if (user.operational_role !== 'ADMIN') {
    // Restrict to vendor's managed outlets
    query += `
      WHERE o.outlet_id IN (
        SELECT id FROM outlets WHERE vendor_owner_id = ?
        UNION
        SELECT outlet_id FROM outlet_staff WHERE user_id = ? AND status = 'ACTIVE'
      )
    `;
    params.push(user.id, user.id);
  }

  query += ' ORDER BY o.created_at DESC LIMIT 100';

  const rows = db.prepare(query).all(...params) as any[];
  const result = rows.map(o => {
    const items = db.prepare(`
      SELECT item_name_snapshot as name, unit_price_snapshot as unit_price, quantity, item_total as line_total
      FROM order_items
      WHERE order_id = ?
    `).all(o.id);

    return {
      id: o.id,
      order_number: o.order_number,
      outlet_id: o.outlet_id,
      outlet_name: o.outlet_name,
      pickup_counter: o.pickup_counter,
      status: o.order_status,
      order_status: o.order_status,
      payment_status: o.payment_status,
      total: o.total_amount,
      total_amount: o.total_amount,
      pickup_token: o.pickup_token,
      created_at: o.created_at,
      items,
    };
  });

  sendSuccess(res, result);
});

// Order Lifecycle Status Transitions
const VALID_TRANSITIONS: Record<string, string[]> = {
  PLACED: ['ACCEPTED', 'PREPARING', 'CANCELLED', 'REJECTED'],
  ACCEPTED: ['PREPARING', 'CANCELLED'],
  PREPARING: ['READY', 'CANCELLED'],
  READY: ['COMPLETED'],
  COMPLETED: [],
  CANCELLED: [],
  REJECTED: [],
};

orderRouter.patch('/:id/status', requireVendorOrAdmin, (req, res) => {
  const orderId = parseInt(req.params.id, 10);
  const { status } = req.body;
  const nextStatus = status ? status.toUpperCase() : null;

  if (!nextStatus) {
    sendError(res, 400, 'BAD_REQUEST', 'status is required.');
    return;
  }

  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId) as any;
  if (!order) {
    sendError(res, 404, 'NOT_FOUND', 'Order not found.');
    return;
  }

  const allowedNext = VALID_TRANSITIONS[order.order_status] || [];
  if (!allowedNext.includes(nextStatus)) {
    sendError(
      res,
      400,
      'INVALID_STATUS_TRANSITION',
      `Cannot transition order from ${order.order_status} to ${nextStatus}. Allowed: [${allowedNext.join(', ')}]`
    );
    return;
  }

  db.prepare(`
    UPDATE orders
    SET order_status = ?, updated_at = datetime('now')
    WHERE id = ?
  `).run(nextStatus, orderId);

  sendSuccess(res, { id: orderId, status: nextStatus, order_status: nextStatus }, `Order updated to ${nextStatus}.`);
});

// Pickup Token Verification at Counter
orderRouter.post('/:id/verify-pickup', requireVendorOrAdmin, (req, res) => {
  const orderId = parseInt(req.params.id, 10);
  const { pickup_token } = req.body;

  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId) as any;
  if (!order) {
    sendError(res, 404, 'NOT_FOUND', 'Order not found.');
    return;
  }

  if (order.pickup_token !== pickup_token) {
    sendError(res, 400, 'INVALID_TOKEN', 'Pickup token mismatch. Please re-check the QR token.');
    return;
  }

  if (order.order_status === 'COMPLETED') {
    sendError(res, 409, 'ALREADY_COMPLETED', 'This order has already been verified and delivered.');
    return;
  }

  db.prepare(`
    UPDATE orders
    SET order_status = 'COMPLETED', updated_at = datetime('now')
    WHERE id = ?
  `).run(orderId);

  sendSuccess(res, { id: orderId, status: 'COMPLETED' }, 'Pickup token verified. Order delivered.');
});
