import { Router } from 'express';
import { db, runTransaction } from '../db/database';
import { requireAuth } from '../middleware/auth';
import { sendSuccess, sendError } from '../middleware/responseContract';

export const reservationRouter = Router();

// Housekeeping helper: Expire old reservations
function expireOverdueReservations() {
  const now = new Date().toISOString();
  // Mark expired reservations
  db.prepare(`
    UPDATE reservations
    SET reservation_status = 'EXPIRED', updated_at = datetime('now')
    WHERE reservation_status = 'CONFIRMED'
      AND end_time < time('now', 'localtime')
      AND reservation_date <= date('now', 'localtime')
  `).run();

  // Reset table status if no active confirmed reservations
  db.prepare(`
    UPDATE outlet_tables
    SET status = 'available'
    WHERE status = 'reserved'
      AND id NOT IN (
        SELECT table_id FROM reservations
        WHERE reservation_status = 'CONFIRMED'
      )
  `).run();
}

// List Tables with Live Availability
reservationRouter.get(['/', '/tables'], (_req, res) => {
  expireOverdueReservations();

  const tables = db.prepare(`
    SELECT
      t.*,
      o.outlet_name,
      r.reservation_number,
      r.start_time,
      r.end_time,
      u.full_name as reserved_by
    FROM outlet_tables t
    JOIN outlets o ON t.outlet_id = o.id
    LEFT JOIN reservations r ON t.id = r.table_id AND r.reservation_status = 'CONFIRMED'
    LEFT JOIN users u ON r.user_id = u.id
    ORDER BY t.table_number ASC
  `).all() as any[];

  const result = tables.map(t => ({
    id: t.id,
    outlet_id: t.outlet_id,
    outlet_name: t.outlet_name,
    table_number: t.table_number,
    capacity: t.capacity,
    location: t.location,
    status: t.status,
    reserved_by: t.reserved_by || undefined,
    expires_at: t.end_time || undefined,
  }));

  sendSuccess(res, result);
});

// Reserve a Table (Atomic Concurrency Protection)
reservationRouter.post(['/:id/reserve', '/tables/:id/reserve', '/reserve'], requireAuth, (req, res) => {
  expireOverdueReservations();

  const user = req.user!;
  const tableId = parseInt(req.params.id || req.body.table_id, 10);
  const durationMin = Math.min(60, Math.max(10, Number(req.body.duration_minutes) || 15));
  const partySize = Number(req.body.party_size) || 2;

  if (isNaN(tableId)) {
    sendError(res, 400, 'BAD_REQUEST', 'Valid table ID required.');
    return;
  }

  try {
    const reservation = runTransaction(() => {
      // 1. Lock and check table availability
      const table = db.prepare(`
        SELECT * FROM outlet_tables WHERE id = ?
      `).get(tableId) as any;

      if (!table) {
        throw new Error('Table does not exist.');
      }

      if (table.status !== 'available') {
        throw new Error(`Table ${table.table_number} is currently ${table.status}.`);
      }

      // 2. Concurrency check: Ensure no active conflicting reservation exists
      const conflict = db.prepare(`
        SELECT id FROM reservations
        WHERE table_id = ?
          AND reservation_status = 'CONFIRMED'
          AND reservation_date = date('now', 'localtime')
      `).get(tableId);

      if (conflict) {
        throw new Error(`Table ${table.table_number} has just been reserved by another student.`);
      }

      // 3. Calculate start & end times
      const now = new Date();
      const startTime = now.toTimeString().slice(0, 5); // HH:MM
      const expiry = new Date(now.getTime() + durationMin * 60 * 1000);
      const endTime = expiry.toTimeString().slice(0, 5);
      const today = now.toISOString().slice(0, 10);
      const resNum = 'RES-' + Math.floor(10000 + Math.random() * 90000).toString();

      // 4. Mark table as reserved
      db.prepare(`
        UPDATE outlet_tables SET status = 'reserved' WHERE id = ?
      `).run(tableId);

      // 5. Insert reservation record
      const insert = db.prepare(`
        INSERT INTO reservations (
          reservation_number, user_id, outlet_id, table_id,
          reservation_date, start_time, end_time, party_size, reservation_status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'CONFIRMED')
      `).run(
        resNum,
        user.id,
        table.outlet_id,
        tableId,
        today,
        startTime,
        endTime,
        partySize
      );

      return {
        id: Number(insert.lastInsertRowid),
        reservation_number: resNum,
        table: {
          id: table.id,
          table_number: table.table_number,
          capacity: table.capacity,
          location: table.location,
          status: 'reserved',
          reserved_by: user.full_name,
          expires_at: endTime,
        },
      };
    });

    sendSuccess(res, reservation, `Table reserved until ${reservation.table.expires_at} (${durationMin} min hold).`, 201);
  } catch (err: any) {
    sendError(res, 409, 'RESERVATION_CONFLICT', err.message || 'Could not complete reservation.');
  }
});

// Cancel / Release a Table Hold
reservationRouter.post(['/tables/:id/cancel', '/:id/cancel'], requireAuth, (req, res) => {
  const user = req.user!;
  const tableId = parseInt(req.params.id, 10);

  if (isNaN(tableId)) {
    sendError(res, 400, 'BAD_REQUEST', 'Valid table ID required.');
    return;
  }

  runTransaction(() => {
    // Release table
    db.prepare(`
      UPDATE outlet_tables SET status = 'available' WHERE id = ?
    `).run(tableId);

    // Mark user's reservation cancelled
    db.prepare(`
      UPDATE reservations
      SET reservation_status = 'CANCELLED', updated_at = datetime('now')
      WHERE table_id = ? AND reservation_status = 'CONFIRMED'
    `).run(tableId);
  });

  const table = db.prepare('SELECT * FROM outlet_tables WHERE id = ?').get(tableId) as any;
  sendSuccess(res, { success: true, table }, 'Table released.');
});

// Student's Reservations
reservationRouter.get('/mine', requireAuth, (req, res) => {
  const user = req.user!;
  const rows = db.prepare(`
    SELECT
      r.*,
      t.table_number,
      t.location,
      o.outlet_name
    FROM reservations r
    JOIN outlet_tables t ON r.table_id = t.id
    JOIN outlets o ON r.outlet_id = o.id
    WHERE r.user_id = ?
    ORDER BY r.created_at DESC
  `).all(user.id);

  sendSuccess(res, rows);
});
