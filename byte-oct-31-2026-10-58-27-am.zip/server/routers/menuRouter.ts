import { Router } from 'express';
import { db } from '../db/database';
import { requireVendorOrAdmin } from '../middleware/auth';
import { sendSuccess, sendError } from '../middleware/responseContract';

export const menuRouter = Router();

// Flat Food Item Listing with Search & Filter
menuRouter.get('/', (req, res) => {
  const search = (req.query.search as string || '').trim().toLowerCase();
  const outletId = req.query.outlet_id ? parseInt(req.query.outlet_id as string, 10) : null;
  const diet = req.query.diet as string; // 'VEG' | 'NON_VEG'

  let query = `
    SELECT
      m.*,
      o.outlet_name,
      c.category_name
    FROM menu_items m
    JOIN outlets o ON m.outlet_id = o.id
    JOIN menu_categories c ON m.category_id = c.id
    WHERE m.availability_status != 'HIDDEN'
  `;
  const params: any[] = [];

  if (outletId) {
    query += ' AND m.outlet_id = ?';
    params.push(outletId);
  }

  if (diet && diet !== 'ALL') {
    query += ' AND m.food_type = ?';
    params.push(diet.toUpperCase());
  }

  if (search) {
    query += ' AND (LOWER(m.item_name) LIKE ? OR LOWER(m.description) LIKE ? OR LOWER(o.outlet_name) LIKE ?)';
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }

  query += ' ORDER BY m.display_order ASC, m.id ASC';

  const rows = db.prepare(query).all(...params) as any[];

  const items = rows.map(i => ({
    id: i.id,
    outlet_id: i.outlet_id,
    outlet_name: i.outlet_name,
    category_id: i.category_id,
    category_name: i.category_name,
    name: i.item_name,
    item_name: i.item_name,
    description: i.description,
    price: i.price,
    image_url: i.image_url,
    prep_minutes: i.preparation_time,
    preparation_time: i.preparation_time,
    dietary_type: i.food_type === 'NON_VEG' ? 'non_veg' : 'veg',
    food_type: i.food_type,
    is_jain: i.dietary_tags ? i.dietary_tags.includes('JAIN') : false,
    dietary_tags: typeof i.dietary_tags === 'string' ? JSON.parse(i.dietary_tags || '[]') : [],
    allergens: typeof i.allergens === 'string' ? JSON.parse(i.allergens || '[]') : [],
    is_available: i.availability_status === 'AVAILABLE',
    availability_status: i.availability_status,
    available_quantity: i.stock_quantity,
    stock_quantity: i.stock_quantity,
    rating: i.rating,
    is_popular: Boolean(i.is_popular),
  }));

  sendSuccess(res, items);
});

// Single Food Item
menuRouter.get('/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const item = db.prepare(`
    SELECT m.*, o.outlet_name, c.category_name
    FROM menu_items m
    JOIN outlets o ON m.outlet_id = o.id
    JOIN menu_categories c ON m.category_id = c.id
    WHERE m.id = ?
  `).get(id) as any;

  if (!item) {
    sendError(res, 404, 'NOT_FOUND', 'Menu item not found.');
    return;
  }

  sendSuccess(res, {
    ...item,
    name: item.item_name,
    prep_minutes: item.preparation_time,
    dietary_type: item.food_type === 'NON_VEG' ? 'non_veg' : 'veg',
    is_jain: item.dietary_tags ? item.dietary_tags.includes('JAIN') : false,
    is_available: item.availability_status === 'AVAILABLE',
    available_quantity: item.stock_quantity,
    is_popular: Boolean(item.is_popular),
  });
});

// Create Item
menuRouter.post('/', requireVendorOrAdmin, (req, res) => {
  const {
    outlet_id,
    category_id,
    name,
    item_name,
    description,
    price,
    image_url,
    food_type,
    dietary_type,
    dietary_tags,
    allergens,
    prep_minutes,
    preparation_time,
    stock_quantity,
    is_popular,
  } = req.body;

  const resolvedName = item_name || name;
  const resolvedPrice = Number(price);

  if (!outlet_id || !resolvedName || isNaN(resolvedPrice) || resolvedPrice < 0) {
    sendError(res, 400, 'BAD_REQUEST', 'outlet_id, name, and a valid non-negative price are required.');
    return;
  }

  const normalizedFoodType = (food_type || (dietary_type === 'non_veg' ? 'NON_VEG' : 'VEG')).toUpperCase();
  const prep = Number(preparation_time || prep_minutes) || 10;
  const stock = Number(stock_quantity) || 50;
  const defaultImg = "/src/assets/images/pav_bhaji_fisheye_1793394718269.jpg";

  const result = db.prepare(`
    INSERT INTO menu_items (
      outlet_id, category_id, item_name, description, price, image_url,
      food_type, dietary_tags, allergens, preparation_time, availability_status,
      stock_quantity, is_popular
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'AVAILABLE', ?, ?)
  `).run(
    outlet_id,
    category_id || 1,
    resolvedName,
    description || 'Freshly made on campus.',
    resolvedPrice,
    image_url || defaultImg,
    normalizedFoodType,
    JSON.stringify(dietary_tags || []),
    JSON.stringify(allergens || []),
    prep,
    stock,
    is_popular ? 1 : 0
  );

  const created = db.prepare('SELECT * FROM menu_items WHERE id = ?').get(result.lastInsertRowid) as any;
  sendSuccess(res, {
    ...created,
    name: created.item_name,
    prep_minutes: created.preparation_time,
    is_available: true,
  }, 'Menu item created.', 201);
});

// Update Item
menuRouter.patch('/:id', requireVendorOrAdmin, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const {
    name,
    item_name,
    description,
    price,
    image_url,
    prep_minutes,
    preparation_time,
    food_type,
    stock_quantity,
    is_popular,
  } = req.body;

  const resolvedName = item_name || name;
  const prep = preparation_time || prep_minutes;

  db.prepare(`
    UPDATE menu_items
    SET item_name = COALESCE(?, item_name),
        description = COALESCE(?, description),
        price = COALESCE(?, price),
        image_url = COALESCE(?, image_url),
        preparation_time = COALESCE(?, preparation_time),
        food_type = COALESCE(?, food_type),
        stock_quantity = COALESCE(?, stock_quantity),
        is_popular = COALESCE(?, is_popular),
        updated_at = datetime('now')
    WHERE id = ?
  `).run(
    resolvedName,
    description,
    price !== undefined ? Number(price) : null,
    image_url,
    prep !== undefined ? Number(prep) : null,
    food_type,
    stock_quantity !== undefined ? Number(stock_quantity) : null,
    is_popular !== undefined ? (is_popular ? 1 : 0) : null,
    id
  );

  const updated = db.prepare('SELECT * FROM menu_items WHERE id = ?').get(id);
  sendSuccess(res, updated, 'Menu item updated.');
});

// Toggle Availability (AVAILABLE / SOLD_OUT)
menuRouter.patch('/:id/availability', requireVendorOrAdmin, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const { is_available, status } = req.body;

  let newStatus = 'AVAILABLE';
  if (is_available !== undefined) {
    newStatus = is_available ? 'AVAILABLE' : 'SOLD_OUT';
  } else if (status) {
    newStatus = status.toUpperCase();
  }

  db.prepare(`
    UPDATE menu_items SET availability_status = ?, updated_at = datetime('now') WHERE id = ?
  `).run(newStatus, id);

  sendSuccess(res, { id, is_available: newStatus === 'AVAILABLE', availability_status: newStatus }, 'Availability updated.');
});

// Update Stock Quantity
menuRouter.patch('/:id/stock', requireVendorOrAdmin, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const stock = Number(req.body.stock_quantity);

  if (isNaN(stock) || stock < 0) {
    sendError(res, 400, 'BAD_REQUEST', 'stock_quantity must be a non-negative integer.');
    return;
  }

  db.prepare(`
    UPDATE menu_items
    SET stock_quantity = ?,
        availability_status = CASE WHEN ? = 0 THEN 'SOLD_OUT' ELSE 'AVAILABLE' END,
        updated_at = datetime('now')
    WHERE id = ?
  `).run(stock, stock, id);

  sendSuccess(res, { id, stock_quantity: stock }, 'Stock quantity updated.');
});

// Deactivate / Delete Item
menuRouter.delete('/:id', requireVendorOrAdmin, (req, res) => {
  const id = parseInt(req.params.id, 10);
  db.prepare("UPDATE menu_items SET availability_status = 'HIDDEN', updated_at = datetime('now') WHERE id = ?").run(id);
  sendSuccess(res, { id, status: 'HIDDEN' }, 'Menu item deactivated.');
});
