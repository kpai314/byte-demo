import { Router } from 'express';
import { db } from '../db/database';
import { requireVendorOrAdmin } from '../middleware/auth';
import { sendSuccess, sendError } from '../middleware/responseContract';

export const vendorRouter = Router();

// Vendor's Authorized Outlets
vendorRouter.get('/outlets', requireVendorOrAdmin, (req, res) => {
  const user = req.user!;
  let query = 'SELECT * FROM outlets';
  const params: any[] = [];

  if (user.operational_role !== 'ADMIN') {
    query += `
      WHERE vendor_owner_id = ?
         OR id IN (SELECT outlet_id FROM outlet_staff WHERE user_id = ? AND status = 'ACTIVE')
    `;
    params.push(user.id, user.id);
  }

  query += ' ORDER BY id ASC';
  const rows = db.prepare(query).all(...params) as any[];

  const result = rows.map(o => ({
    id: o.id,
    name: o.outlet_name,
    outlet_name: o.outlet_name,
    slug: o.slug,
    description: o.description,
    location: o.location,
    status: o.outlet_status.toLowerCase(),
    outlet_status: o.outlet_status,
    crowd_level: o.crowd_level,
    avg_wait_min: o.avg_wait_min,
  }));

  sendSuccess(res, result);
});

// Vendor's Orders Queue
vendorRouter.get('/orders', requireVendorOrAdmin, (req, res) => {
  const user = req.user!;
  let query = `
    SELECT o.*, out.outlet_name
    FROM orders o
    JOIN outlets out ON o.outlet_id = out.id
  `;
  const params: any[] = [];

  if (user.operational_role !== 'ADMIN') {
    query += `
      WHERE o.outlet_id IN (
        SELECT id FROM outlets WHERE vendor_owner_id = ?
        UNION
        SELECT outlet_id FROM outlet_staff WHERE user_id = ? AND status = 'ACTIVE'
      )
    `;
    params.push(user.id, user.id);
  }

  query += ' ORDER BY o.created_at DESC LIMIT 100';
  const rows = db.prepare(query).all(...params) as any[];

  const result = rows.map(o => {
    const items = db.prepare(`
      SELECT item_name_snapshot as name, unit_price_snapshot as unit_price, quantity, item_total as line_total
      FROM order_items
      WHERE order_id = ?
    `).all(o.id);

    return {
      id: o.id,
      order_number: o.order_number,
      outlet_id: o.outlet_id,
      outlet_name: o.outlet_name,
      pickup_counter: o.pickup_counter,
      status: o.order_status,
      order_status: o.order_status,
      total: o.total_amount,
      pickup_token: o.pickup_token,
      created_at: o.created_at,
      items,
    };
  });

  sendSuccess(res, result);
});

// Update Order Status in Kitchen Queue
vendorRouter.patch('/orders/:orderId/status', requireVendorOrAdmin, (req, res) => {
  const orderId = parseInt(req.params.orderId, 10);
  const { status } = req.body;
  const nextStatus = status ? status.toUpperCase() : null;

  if (!nextStatus) {
    sendError(res, 400, 'BAD_REQUEST', 'status is required.');
    return;
  }

  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId) as any;
  if (!order) {
    sendError(res, 404, 'NOT_FOUND', 'Order not found.');
    return;
  }

  db.prepare(`
    UPDATE orders SET order_status = ?, updated_at = datetime('now') WHERE id = ?
  `).run(nextStatus, orderId);

  sendSuccess(res, { id: orderId, status: nextStatus }, `Order updated to ${nextStatus}.`);
});

// Add Item to Outlet Menu
vendorRouter.post('/outlets/:outletId/items', requireVendorOrAdmin, (req, res) => {
  const outletId = parseInt(req.params.outletId, 10);
  const {
    name,
    description,
    price,
    image_url,
    prep_minutes,
    dietary_type,
    is_jain,
    category_id,
  } = req.body;

  const resolvedPrice = Number(price);
  if (!name || isNaN(resolvedPrice) || resolvedPrice < 0) {
    sendError(res, 400, 'BAD_REQUEST', 'Valid name and non-negative price required.');
    return;
  }

  const defaultImg = '/src/assets/images/pav_bhaji_fisheye_1793394718269.jpg';
  const foodType = dietary_type === 'non_veg' ? 'NON_VEG' : 'VEG';
  const tags = is_jain ? ['JAIN'] : [];

  const result = db.prepare(`
    INSERT INTO menu_items (
      outlet_id, category_id, item_name, description, price, image_url,
      food_type, dietary_tags, preparation_time, availability_status, stock_quantity
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'AVAILABLE', 50)
  `).run(
    outletId,
    category_id || 1,
    name,
    description || 'Freshly made on campus.',
    resolvedPrice,
    image_url || defaultImg,
    foodType,
    JSON.stringify(tags),
    Number(prep_minutes) || 10
  );

  const created = db.prepare('SELECT * FROM menu_items WHERE id = ?').get(result.lastInsertRowid) as any;
  sendSuccess(res, {
    ...created,
    name: created.item_name,
    prep_minutes: created.preparation_time,
    is_available: true,
  }, 'Item added.', 201);
});

// Toggle Item Availability
vendorRouter.patch('/items/:itemId/availability', requireVendorOrAdmin, (req, res) => {
  const itemId = parseInt(req.params.itemId, 10);
  const { is_available } = req.body;
  const status = is_available ? 'AVAILABLE' : 'SOLD_OUT';

  db.prepare(`
    UPDATE menu_items SET availability_status = ?, updated_at = datetime('now') WHERE id = ?
  `).run(status, itemId);

  sendSuccess(res, { id: itemId, is_available: Boolean(is_available), availability_status: status });
});
