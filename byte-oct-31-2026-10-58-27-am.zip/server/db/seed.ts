import bcrypt from 'bcryptjs';
import { db, runTransaction } from './database';

const MASALA_DOSA_IMG = "/src/assets/images/masala_dosa_fisheye_1793394719149.jpg";
const PAV_BHAJI_IMG = "/src/assets/images/pav_bhaji_fisheye_1793394718269.jpg";
const VADA_PAV_IMG = "/src/assets/images/vada_pav_fisheye_1793394718933.jpg";
const PANEER_BUTTER_IMG = "/src/assets/images/paneer_butter_masala_fisheye_1793394718861.jpg";

export function seedDatabase() {
  const campusCount = db.prepare('SELECT COUNT(*) as count FROM campuses').get() as { count: number };
  if (campusCount.count > 0) {
    return; // Already seeded
  }

  runTransaction(() => {
    // 1. Campus
    const insertCampus = db.prepare(`
      INSERT INTO campuses (id, name, campus_code, location, status)
      VALUES (1, 'Dwarkadas J. Sanghvi College of Engineering', 'DJSCE', 'Vile Parle (West), Mumbai', 'ACTIVE')
    `);
    insertCampus.run();

    // 2. Users with Hashed Passwords
    const saltRounds = 10;
    const adminHash = bcrypt.hashSync('ByteAdmin123!', saltRounds);
    const vendorHash = bcrypt.hashSync('ByteVendor123!', saltRounds);
    const studentHash = bcrypt.hashSync('ByteStudent123!', saltRounds);
    const facultyHash = bcrypt.hashSync('ByteFaculty123!', saltRounds);

    const insertUser = db.prepare(`
      INSERT INTO users (id, full_name, email, phone, password_hash, campus_id, user_category, operational_role, account_status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insertUser.run(1, 'BYTE Administrator', 'admin@example.com', '+91 98200 00001', adminHash, 1, 'NON_TEACHING_STAFF', 'ADMIN', 'ACTIVE');
    insertUser.run(2, 'Dabba Lab Vendor', 'vendor@example.com', '+91 98200 00002', vendorHash, 1, 'NON_TEACHING_STAFF', 'VENDOR', 'ACTIVE');
    insertUser.run(3, 'Tiffin Express Vendor', 'vendor.tiffin@example.com', '+91 98200 00003', vendorHash, 1, 'NON_TEACHING_STAFF', 'VENDOR', 'ACTIVE');
    insertUser.run(4, 'Chai & Crumb Vendor', 'vendor.chai@example.com', '+91 98200 00004', vendorHash, 1, 'NON_TEACHING_STAFF', 'VENDOR', 'ACTIVE');
    insertUser.run(5, 'KEERTHI', 'student@example.com', '+91 98200 12345', studentHash, 1, 'STUDENT', 'USER', 'ACTIVE');
    insertUser.run(6, 'Prof. K. Sharma', 'prof.sharma@example.com', '+91 98200 54321', facultyHash, 1, 'FACULTY', 'USER', 'ACTIVE');

    // 3. Outlets
    const insertOutlet = db.prepare(`
      INSERT INTO outlets (id, campus_id, outlet_name, slug, description, location, opening_time, closing_time, outlet_status, crowd_level, avg_wait_min, vendor_owner_id)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insertOutlet.run(1, 1, 'Central Canteen', 'central-canteen', 'Everyday comfort meals, fresh tiffin, and live chaat.', 'Ground Floor · Main Building', '08:00', '19:30', 'ACTIVE', 'MODERATE', 12, 2);
    insertOutlet.run(2, 1, 'South Indian Corner', 'south-indian-corner', 'Crisp dosas, idlis, vadas & filter coffee.', 'Food Court · North Wing', '07:30', '18:00', 'ACTIVE', 'LOW', 7, 3);
    insertOutlet.run(3, 1, 'Beverage & Snack Station', 'beverage-station', 'Cutting chai, cold coffee, sandwiches, and bakery treats.', 'Library Quadrangle', '08:00', '20:30', 'ACTIVE', 'HIGH', 15, 4);

    // 4. Outlet Staff
    const insertStaff = db.prepare(`
      INSERT INTO outlet_staff (outlet_id, user_id, staff_role, status)
      VALUES (?, ?, ?, ?)
    `);
    insertStaff.run(1, 2, 'MANAGER', 'ACTIVE');
    insertStaff.run(2, 3, 'MANAGER', 'ACTIVE');
    insertStaff.run(3, 4, 'MANAGER', 'ACTIVE');

    // 5. Menu Categories
    const insertCat = db.prepare(`
      INSERT INTO menu_categories (id, outlet_id, category_name, description, display_order, is_active)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    insertCat.run(1, 1, 'Popular', 'Campus crowd favorites', 1, 1);
    insertCat.run(2, 1, 'Mains & Meals', 'Filling and nutritious hot plates', 2, 1);
    insertCat.run(3, 1, 'Quick Snacks', 'Fast grab-and-go bites', 3, 1);
    insertCat.run(4, 2, 'Breakfast & Tiffin', 'Freshly steamed and griddled South Indian fare', 1, 1);
    insertCat.run(5, 2, 'Combos', 'Pairings with filter coffee', 2, 1);
    insertCat.run(6, 3, 'Hot & Cold Brews', 'Teas, coffees and refreshers', 1, 1);
    insertCat.run(7, 3, 'Bites & Bakery', 'Puffs, buns and cookies', 2, 1);

    // 6. Menu Items
    const insertFood = db.prepare(`
      INSERT INTO menu_items (id, outlet_id, category_id, item_name, description, price, image_url, food_type, dietary_tags, allergens, preparation_time, availability_status, stock_quantity, display_order, rating, is_popular)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insertFood.run(
      1, 1, 1, "Mumbai Pav Bhaji",
      "Slow-simmered spiced bhaji with melting butter slab, served with buttered toasted pav & fresh chopped onions.",
      80.0, PAV_BHAJI_IMG, "VEG", JSON.stringify(["JAIN", "POPULAR"]), JSON.stringify(["DAIRY", "GLUTEN"]),
      8, "AVAILABLE", 45, 1, 4.9, 1
    );

    insertFood.run(
      2, 1, 1, "Authentic Mumbai Vada Pav",
      "The classic DJSCE campus fuel: Spiced golden batata vada in pav, layered with red garlic chutney & fried chilli.",
      25.0, VADA_PAV_IMG, "VEG", JSON.stringify(["POPULAR"]), JSON.stringify(["GLUTEN"]),
      4, "AVAILABLE", 60, 2, 4.8, 1
    );

    insertFood.run(
      3, 1, 2, "Paneer Butter Masala",
      "Silky tomato-cashew makhani gravy with tender cottage cheese, fresh cream swirl & warm butter tandoori naan.",
      120.0, PANEER_BUTTER_IMG, "VEG", JSON.stringify(["NORTH_INDIAN"]), JSON.stringify(["DAIRY", "NUTS", "GLUTEN"]),
      12, "AVAILABLE", 30, 3, 4.9, 1
    );

    insertFood.run(
      4, 1, 2, "Campus Special Veg Thali",
      "Complete student meal: 2 Phulkas, Paneer Subzi, Dal Tadka, Steamed Jeera Rice, Curd & Gulab Jamun.",
      90.0, PANEER_BUTTER_IMG, "VEG", JSON.stringify(["JAIN", "THALI"]), JSON.stringify(["DAIRY", "GLUTEN"]),
      12, "AVAILABLE", 40, 4, 4.7, 0
    );

    insertFood.run(
      5, 1, 3, "Grilled Paneer Wrap",
      "Spiced paneer tikka slices with crunchy bell peppers, mint yogurt dressing and pickled onions rolled in flatbread.",
      80.0, VADA_PAV_IMG, "VEG", JSON.stringify(["QUICK_BITES"]), JSON.stringify(["DAIRY", "GLUTEN"]),
      7, "AVAILABLE", 25, 5, 4.6, 0
    );

    insertFood.run(
      6, 2, 4, "Mysore Masala Dosa",
      "Crisp roasted fermented rice crepe smeared with spicy red chutney, stuffed with spiced potato bhaji, served with coconut chutney & sambar.",
      70.0, MASALA_DOSA_IMG, "VEG", JSON.stringify(["SOUTH_INDIAN", "JAIN"]), JSON.stringify(["MUSTARD"]),
      10, "AVAILABLE", 50, 1, 5.0, 1
    );

    insertFood.run(
      7, 2, 4, "Steamed Idli Sambar (2 Pcs)",
      "Pillow-soft steamed rice & lentil cakes dipped in hot aromatic drumstick sambar with tempered coconut chutney.",
      45.0, MASALA_DOSA_IMG, "VEG", JSON.stringify(["SOUTH_INDIAN", "JAIN", "LOW_CALORIE"]), JSON.stringify([]),
      5, "AVAILABLE", 40, 2, 4.7, 0
    );

    insertFood.run(
      8, 2, 5, "South Indian Tiffin Combo",
      "1 Mini Masala Dosa + 1 Steamed Idli + 1 Medu Vada with hot filter coffee.",
      110.0, MASALA_DOSA_IMG, "VEG", JSON.stringify(["COMBO"]), JSON.stringify(["DAIRY"]),
      12, "AVAILABLE", 20, 3, 4.9, 1
    );

    insertFood.run(
      9, 3, 6, "Special Cutting Chai",
      "Double cardamom, crushed ginger, boiled strong Assam CTC tea with thick boiled milk.",
      15.0, MASALA_DOSA_IMG, "VEG", JSON.stringify(["BEVERAGE"]), JSON.stringify(["DAIRY"]),
      3, "AVAILABLE", 120, 1, 4.9, 1
    );

    insertFood.run(
      10, 3, 6, "Chilled Cold Coffee with Ice Cream",
      "Thick espresso blitz with milk and ice, topped with a scoop of vanilla ice cream & cocoa dusting.",
      60.0, PAV_BHAJI_IMG, "VEG", JSON.stringify(["BEVERAGE", "DESSERT"]), JSON.stringify(["DAIRY"]),
      5, "AVAILABLE", 35, 2, 4.8, 1
    );

    insertFood.run(
      11, 1, 2, "Chicken Dum Biryani",
      "Fragrant basmati rice layered with marinated chicken, saffron, fried onions, and served with cucumber raita.",
      120.0, MASALA_DOSA_IMG, "NON_VEG", JSON.stringify(["NON_VEG", "BIRYANI"]), JSON.stringify(["DAIRY"]),
      15, "SOLD_OUT", 0, 6, 4.8, 1
    );

    insertFood.run(
      12, 1, 2, "Amritsari Chole Bhature",
      "Two huge puffed golden bhaturas served with spicy dark Punjabi chole, pickle and onion rings.",
      90.0, PAV_BHAJI_IMG, "VEG", JSON.stringify(["NORTH_INDIAN"]), JSON.stringify(["GLUTEN"]),
      12, "AVAILABLE", 30, 7, 4.8, 1
    );

    // 7. Outlet Tables
    const insertTable = db.prepare(`
      INSERT INTO outlet_tables (id, outlet_id, table_number, capacity, location, status)
      VALUES (?, ?, ?, ?, ?, ?)
    `);

    insertTable.run(1, 1, 'T-01', 4, 'Main Hall · Window Side', 'available');
    insertTable.run(2, 1, 'T-02', 4, 'Main Hall · Central', 'occupied');
    insertTable.run(3, 1, 'T-03', 2, 'Main Hall · Quick Nook', 'available');
    insertTable.run(4, 1, 'T-04', 6, 'Booth A · Faculty Corner', 'reserved');
    insertTable.run(5, 1, 'T-05', 4, 'Courtyard Veranda', 'available');
    insertTable.run(6, 1, 'T-06', 4, 'Courtyard Veranda', 'occupied');
    insertTable.run(7, 1, 'T-07', 2, 'High Top · Express Bar', 'available');
    insertTable.run(8, 1, 'T-08', 6, 'Booth B · Study Group', 'available');
    insertTable.run(9, 1, 'T-09', 4, 'South Terrace', 'occupied');
    insertTable.run(10, 1, 'T-10', 4, 'South Terrace', 'reserved');
    insertTable.run(11, 1, 'T-11', 2, 'Library Exit Zone', 'available');
    insertTable.run(12, 1, 'T-12', 6, 'Booth C · Lounge Area', 'available');

    // 8. Initial Orders & Items
    const insertOrder = db.prepare(`
      INSERT INTO orders (id, order_number, idempotency_key, user_id, outlet_id, subtotal, taxes, discounts, total_amount, payment_status, order_status, pickup_token, pickup_counter, pickup_type, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now', '-6 minutes'))
    `);
    insertOrder.run(1001, 'B1234', 'seed-1', 5, 1, 105.0, 0, 0, 105.0, 'PAID', 'PREPARING', 'TK-1234-EXP', 'COUNTER 02', 'immediate');

    const insertOrderItem = db.prepare(`
      INSERT INTO order_items (order_id, menu_item_id, item_name_snapshot, unit_price_snapshot, quantity, item_total)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    insertOrderItem.run(1001, 1, 'Mumbai Pav Bhaji', 80.0, 1, 80.0);
    insertOrderItem.run(1001, 2, 'Authentic Mumbai Vada Pav', 25.0, 1, 25.0);

    const insertPayment = db.prepare(`
      INSERT INTO payments (order_id, payment_provider, payment_reference, amount, payment_method, payment_status)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    insertPayment.run(1001, 'SANDBOX_UPI', 'UPI-REF-001', 105.0, 'upi', 'SUCCESS');
  });

  console.log('[BYTE DB] Relational schema and initial DJSCE seed data populated successfully.');
}
