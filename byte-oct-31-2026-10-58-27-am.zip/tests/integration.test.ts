import axios from 'axios';

const BASE_URL = 'http://127.0.0.1:3000';

async function runTests() {
  console.log('--- BYTE CAMPUS FOOD OS INTEGRATION TEST SUITE ---');
  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, msg: string) {
    if (condition) {
      console.log(`[PASS] ${msg}`);
      passed++;
    } else {
      console.error(`[FAIL] ${msg}`);
      failed++;
    }
  }

  // 1. Health check
  try {
    const res = await axios.get(`${BASE_URL}/api/health`);
    assert(res.data.success === true && res.data.data.status === 'ok', 'Health Check API returns success envelope');
  } catch (e: any) {
    assert(false, `Health Check API failed: ${e.message}`);
  }

  // 2. Outlets list
  try {
    const res = await axios.get(`${BASE_URL}/api/outlets`);
    assert(res.data.success === true && Array.isArray(res.data.data) && res.data.data.length >= 3, 'Outlets API returns valid list of canteens');
  } catch (e: any) {
    assert(false, `Outlets API failed: ${e.message}`);
  }

  // 3. Menu items list
  try {
    const res = await axios.get(`${BASE_URL}/api/foods`);
    assert(res.data.success === true && Array.isArray(res.data.data) && res.data.data.length >= 10, 'Foods API returns valid food directory');
  } catch (e: any) {
    assert(false, `Foods API failed: ${e.message}`);
  }

  // 4. Student Authentication
  let studentCookie = '';
  try {
    const res = await axios.post(`${BASE_URL}/api/auth/login`, {
      email: 'student@example.com',
      password: 'ByteStudent123!',
    });
    studentCookie = res.headers['set-cookie']?.[0] || '';
    assert(res.data.success === true && res.data.data.email === 'student@example.com', 'Student authentication succeeds with valid session');
  } catch (e: any) {
    assert(false, `Student Login failed: ${e.message}`);
  }

  // 5. Admin Authentication
  let adminCookie = '';
  try {
    const res = await axios.post(`${BASE_URL}/api/auth/login`, {
      email: 'admin@example.com',
      password: 'ByteAdmin123!',
    });
    adminCookie = res.headers['set-cookie']?.[0] || '';
    assert(res.data.success === true && res.data.data.role === 'admin', 'Admin authentication succeeds with admin role');
  } catch (e: any) {
    assert(false, `Admin Login failed: ${e.message}`);
  }

  // 6. Current User Me
  try {
    const res = await axios.get(`${BASE_URL}/api/auth/me`, {
      headers: { Cookie: studentCookie },
    });
    assert(res.data.success === true && res.data.data.user_type === 'student', 'Auth Me endpoint returns authenticated student profile');
  } catch (e: any) {
    assert(false, `Auth Me failed: ${e.message}`);
  }

  // 7. Single Outlet Cart Validation Rule
  try {
    const res = await axios.post(`${BASE_URL}/api/cart/validate`, {
      outlet_id: 1,
      items: [
        { food_item_id: 1, quantity: 2 },
        { food_item_id: 2, quantity: 1 },
      ],
    });
    assert(res.data.success === true && res.data.data.subtotal === 185, 'Cart validation calculates correct prices from database');
  } catch (e: any) {
    assert(false, `Cart validation failed: ${e.message}`);
  }

  // 8. Order Placement & Idempotency
  const idempKey = `test-order-${Date.now()}`;
  let placedOrderNumber = '';
  let placedOrderId = 0;
  try {
    const res = await axios.post(
      `${BASE_URL}/api/checkout`,
      {
        outlet_id: 1,
        items: [{ food_item_id: 1, quantity: 1 }],
        idempotency_key: idempKey,
        pickup_type: 'immediate',
        payment_method: 'upi',
      },
      { headers: { Cookie: studentCookie } }
    );
    placedOrderNumber = res.data.data.order_number;
    placedOrderId = res.data.data.id;
    assert(res.data.success === true && res.data.data.total === 80, 'Checkout creates order and sandbox payment record in transaction');

    // Test idempotency replay
    const replay = await axios.post(
      `${BASE_URL}/api/checkout`,
      {
        outlet_id: 1,
        items: [{ food_item_id: 1, quantity: 1 }],
        idempotency_key: idempKey,
      },
      { headers: { Cookie: studentCookie } }
    );
    assert(replay.data.data.order_number === placedOrderNumber, 'Idempotency returns existing order without duplicate charging');
  } catch (e: any) {
    assert(false, `Checkout failed: ${e.message}`);
  }

  // 9. Table Reservation with Concurrency Protection
  try {
    const res = await axios.post(
      `${BASE_URL}/api/tables/3/reserve`,
      { duration_minutes: 15, party_size: 2 },
      { headers: { Cookie: studentCookie } }
    );
    assert(res.data.success === true && res.data.data.table.status === 'reserved', 'Table reservation creates hold and marks table reserved');

    // Attempt double-booking should be rejected
    try {
      await axios.post(
        `${BASE_URL}/api/tables/3/reserve`,
        { duration_minutes: 15, party_size: 2 },
        { headers: { Cookie: studentCookie } }
      );
      assert(false, 'Double reservation should have been blocked');
    } catch (err: any) {
      assert(err.response?.status === 409, 'Double reservation rejected with 409 conflict');
    }

    // Release table
    const cancelRes = await axios.post(
      `${BASE_URL}/api/tables/3/cancel`,
      {},
      { headers: { Cookie: studentCookie } }
    );
    assert(cancelRes.data.success === true && cancelRes.data.data.table.status === 'available', 'Table cancellation releases table back to available');
  } catch (e: any) {
    assert(false, `Reservation test failed: ${e.message}`);
  }

  // 10. CSV Validation and Import
  try {
    const testCsv = `outlet_id,category_id,item_name,description,price,food_type,preparation_time,stock_quantity
1,1,"Test Samosa Pav","Golden crispy spiced samosa in buttered pav",30,VEG,4,50`;

    const previewRes = await axios.post(
      `${BASE_URL}/api/admin/csv/preview`,
      { entity_type: 'menu_items', csv_content: testCsv },
      { headers: { Cookie: adminCookie } }
    );
    assert(previewRes.data.data.valid === true && previewRes.data.data.valid_rows_count === 1, 'CSV Preview validates headers and data rows correctly');

    const importRes = await axios.post(
      `${BASE_URL}/api/admin/csv/import`,
      { entity_type: 'menu_items', csv_content: testCsv },
      { headers: { Cookie: adminCookie } }
    );
    assert(importRes.data.data.imported_count === 1, 'CSV Import inserts valid records transactionally into PostgreSQL/SQLite database');
  } catch (e: any) {
    assert(false, `CSV test failed: ${e.message}`);
  }

  console.log(`\n========================================`);
  console.log(`TEST SUMMARY: ${passed} PASSED, ${failed} FAILED`);
  console.log(`========================================`);
  if (failed > 0) process.exit(1);
}

runTests();
